<?php

/**

 * The Header for our theme.

 *

 *

 * @package WordPress

 * @subpackage Klasik

 * @since Klasik 1.0

 */

?>
<?php get_template_part( 'site-header'); ?>

<div id="bodychild">
<div id="outercontainer">

<!-- HEADER -->

<div id="outerheader" class="fixedmenu">
  <div id="headercontainer">
    <div class="container">
      <header id="top">
        <div class="row">
          <div id="logo" class="four columns">
            <?php klasik_logo();?>
          </div>
          <section id="navigation">
            <nav id="nav-wrap">
              <?php wp_nav_menu( array(

                                      'container'       => 'ul', 

                                      'menu_class'      => 'sf-menu',

                                      'menu_id'         => 'topnav', 

                                      'depth'           => 0,

                                      'sort_column'    => 'menu_order',

                                      'theme_location' => 'primarymenu' 

                                      )); 

                                    ?>
            </nav>
            <!-- nav -->
            
            <div class="clear"></div>
          </section>
          <?php if(is_active_sidebar('contenttop') ){ ?><?php if ( ! dynamic_sidebar( 'contenttop' ) ){ } ?><?php } ?>
        </div>
        <div class="clear"></div>
      </header>
    </div>
    <div class="clear"></div>
  </div>
</div>

<!-- END HEADER --> 

<!-- AFTERHEADER --> 

<!-- SLIDER -->

<?php 

		$isfrontpage=is_front_page();

		$args = klasik_get_slider_args();

		global $wp_query;

		$temp = $wp_query;

		$wp_query= null;

		$wp_query = new WP_Query();

		$wp_query->query($args);

		global $post;



		if( $isfrontpage && $wp_query->have_posts()  ){

		

			echo '

			<div id="outerslider">

				<div class="container">

					<div class="row">

						<div class="twelve columns">

						<div id="slidercontainer">

							<section id="slider">

								

			

			';

			

			get_template_part( 'slider-items');

				

			echo '

								

								<div class="clear"></div>

							</section>

							

						</div>

						</div>

					</div>

				</div>

			</div>

			';

			

			$outermainclass = "";

		}else{

			$outermainclass = "noslider"; 

		}

		wp_reset_query();

		?>

<!-- END SLIDER -->

<?php

		if($outermainclass=='noslider'){

		?>
<div id="outerafterheader" class="<?php echo $outermainclass; ?>" <?php echo klasik_page_image() ?>>
  <div class="container">
    <div class="row">
      <div class="twelve columns">
        <div id="afterheader">
          <div id="page-title-wrap">
            <?php

                                    klasik_page_title();
									
									?><div id="post-meta-top"><?php
									if (is_page()) : the_date('m/d/y');
									elseif (is_single()) : ?><?php the_date('m/d/y') ?><?php if( get_post_meta($post->ID, 'quality', true) ) : ?><span class="quality"> Quality: <?php echo get_post_meta($post->ID, 'quality', true); ?></span><?php endif; ?>
                                    <?php elseif (is_archive()) : $count = $GLOBALS['wp_query']->post_count; ?><?php print $count; if ($count == 1) print " Video"; else print " Videos"; ?>
                                    <?php elseif (is_home()) : ?>New porn this week: <?php echo wp_posts_in_days('days=7'); ?>
									<?php endif;  ?>
									<span class="hide-meta"><a href="#" class="hide-meta-button">Hide Meta: Show pictures only</a></span></div>
          </div>
         							<a href="#" class="toggle-mobile-menu">&#9783; Show Menu</a>
                                    <div id="main-menu-wrap"><?php wp_nav_menu( array( 'theme_location' => 'main-menu', 'container_class' => 'main-menu' ) ); ?></div>
									<div id="main-menu-mobile"><?php wp_nav_menu( array( 'theme_location' => 'main-menu', 'container_class' => 'main-menu' ) ); ?></div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php

		}

		?>

<!-- END AFTERHEADER -->

<?php get_template_part('layout-header'); ?>
