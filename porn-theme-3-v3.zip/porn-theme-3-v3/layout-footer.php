<?php 

                        $sidebarposition = esc_attr(klasik_get_option( 'klasik_sidebar_position' ,'two-col-left')); 

                		

						

                        if(is_home()){

							$pid = get_option('page_for_posts');

						}else{

							$pid = '';

						}

						$custom_fields = klasik_get_customdata($pid);

                        

                        $pagelayout = $sidebarposition;

                        

						if(klasik_get_metabox('klasik_layout') && klasik_get_metabox('klasik_layout')!='default' && is_search()!='default'){

							$pagelayout = esc_attr(klasik_get_metabox('klasik_layout'));

						}

						?>

<div class="clear"></div>
</div>
<!-- main -->

<div id="below-content-widgets" class="content-widgets">
<?php if(is_active_sidebar('mainbottom') ){ ?><?php if ( ! dynamic_sidebar( 'mainbottom' ) ){ }?> <?php } ?>
</div>

</section>
<!-- content -->

</section>
<!-- END #maincontent -->

<div class="clear"></div>
</div>
</div>
<!-- END container -->

</div>
<!-- END maincontent-container -->


<div id="sidebar">
<div class="container">
  <?php if(is_active_sidebar('maintop') ){ ?><?php if ( ! dynamic_sidebar( 'maintop' ) ){ } ?><?php } ?>
  <?php get_sidebar();?>
</div>
</div>

</div>
<!-- END maincontainer -->

</div>
<!-- END outermain --> 

<!-- END MAIN CONTENT --> 

