<?php



	/* Always have wp_footer() just before the closing </body>



	 * tag of your theme, or you will break many plugins, which



	 * generally use this hook to reference JavaScript files.



	 */







	wp_footer();



?>
<script>

$( ".hide-meta-button" ).click(function() {

  $( ".thumb-tags" ).fadeToggle( "slow", function(){});

  $( ".thumb-cat" ).fadeToggle( "slow", function(){});
  $( ".thumb-quality" ).fadeToggle( "slow", function(){});
  $( ".thumb-duration" ).fadeToggle( "slow", function(){});

});

$( ".toggle-mobile-menu" ).click(function() {

  $( "#main-menu-mobile" ).fadeToggle("slow", function(){});

  $(this).fadeToggle("slow", function(){});

});

</script>

</body>
</html>