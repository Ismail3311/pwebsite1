<?php
	
function widget_custom_tag_cloud($args) {
 
    // Control number of tags to be displayed - 0 no tags
    $args['number'] = 50;
 
    // Outputs our edited widget
    return $args;
}
add_filter( 'widget_tag_cloud_args', 'widget_custom_tag_cloud' );

/********** KLASIK DEFINITION *************/

global $themeoptionsvalue,  $meta_boxes;



if ( ! isset( $content_width ) ) $content_width = 1140;

$child_path			= get_stylesheet_directory() . '/';

$includes_path 		= get_template_directory() . '/includes/';

$meta_boxes 		= array(); 



define('KLASIK_THEMENAME', 'Klasik Framework');

define('KLASIK_PARENTMENU_SLUG', 'klasiktheme-settings');



/********** END KLASIK DEFINITION *************/



// Theme Options

require_once $includes_path . 'theme-admin.php';


//Theme init

require_once $includes_path . 'theme-init.php';


//Widgets

require_once $includes_path . 'theme-widgets.php';


//Sidebar

require_once $includes_path . 'theme-sidebar.php';


//Additional function

require_once $includes_path . 'theme-function.php';


//Header function

require_once $includes_path . 'header-function.php';


//Footer function

require_once $includes_path . 'footer-function.php';

//Loading Style Css

require_once $includes_path . 'theme-styles.php';


//Pornaffiliate adds

function wp_posts_in_days( $args = '' ) {
	global $wpdb;
	$defaults = array(
		'echo' => 1,
		'days' => 30,
		'lookahead' => 0
	);
	$the_args = wp_parse_args( $args, $defaults );
	extract( $the_args , EXTR_SKIP );
	unset( $args , $the_args , $defaults );
	$days = intval( $days );
	$operator = ( $lookahead != false ) ? '+' : '-';
	$postsindays = $wpdb->get_col( "
		SELECT COUNT(ID)
		FROM $wpdb->posts
		WHERE (1=1
		AND post_type = 'post'
		AND post_status = 'publish'
		AND post_date >= '" . date('Y-m-d', strtotime("$operator$days days")) . "')"
	);
		if($echo != false) :
			echo $postsindays[0];
		else :
			return $postsindays[0];
		endif;
	return;
}


function register_my_menus() {
  register_nav_menus(
    array(
      'main-menu' => __( 'Main Menu' ),
	  'footer-menu' => __( 'Footer Menu' )
    )
  );
}
add_action( 'init', 'register_my_menus' );