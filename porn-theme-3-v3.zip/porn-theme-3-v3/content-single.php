<?php

/**

 * The default template for displaying content. Used for both single and index/archive/search.

 *

 * @package WordPress

 * @subpackage Klasik

 * @since Klasik 1.0

 */

?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<?php if( get_post_meta($post->ID, 'video', true) ) : ?>
        <video controls autoplay onclick="if (this.paused) this.play(); else this.pause(); "><source src="<?php echo get_post_meta($post->ID, 'video', true); ?>" type="video/mp4">Your browser does not support the HTML 5 video. We suggest using <a href="http://www.google.no/search?q=google+chrome‎">Google Chrome</a> (it is free) to see this site and it's videos as intended, thanks!</video>
  		<?php endif; ?>
      <a href="<?php echo get_post_meta($post->ID, 'link', true); ?>" target="_blank" class="c2a">Watch Full Video Here!</a>
      <div id="video-meta">
      <?php if( get_post_meta($post->ID, 'film', true) ) : ?><div class="film-name">Movie Title: <?php echo get_post_meta($post->ID, 'film', true); ?></div><?php endif; ?>
      <div class="tags"><?php the_tags('Niches: ') ?></div>
      <div class="cat">Girls: <?php the_category(', ') ?></div>
      <div id="single-content"><?php echo the_content(); ?></div>
      </div>
</div>
<!-- end post --> 

