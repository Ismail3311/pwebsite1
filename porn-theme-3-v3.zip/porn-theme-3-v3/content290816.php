<?php

/**

 * The default template for displaying content. Used for both single and index/archive/search.

 *

 * @package WordPress

 * @subpackage Klasik

 * @since Klasik 1.0

 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
      <div class="thumb-tags"><?php the_tags('Niches: ') ?></div>
      <a href="<?php echo get_post_meta($post->ID, 'link', true); ?>" target="_blank"><?php if ( has_post_thumbnail() ) {the_post_thumbnail('thumbnail');} ?><?php the_date('m/d/y', '<div class="thumb-date">', '</div>'); ?></a>
      <div class="thumb-cat">Girls: <?php the_category(', ') ?></div>
</article>
<!-- end post --> 

