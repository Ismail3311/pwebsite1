<?php

/**

 * The template for displaying the footer.

 *

 * @package WordPress

 * @subpackage Klasik

 * @since Klasik 1.0

 */

 

?>
<?php get_template_part('layout-footer'); ?>
<?php if(is_active_sidebar('footer1') || is_active_sidebar('footer2') || is_active_sidebar('footer3') || is_active_sidebar('footer4')){ ?>

<!-- FOOTER SIDEBAR -->

<div id="outerfootersidebar">
  <div id="footersidebarcontainer">
    <div class="container">
      <div class="row">
        <footer id="footersidebar">
          <div id="footcol1"  class="three columns">
            <div class="widget-area">
              <?php 

									if ( ! dynamic_sidebar( 'footer1' ) ){



									}// end general widget area 

									?>
            </div>
          </div>
          <div id="footcol2"  class="three columns">
            <div class="widget-area">
              <?php 

									if ( ! dynamic_sidebar( 'footer2' ) ){

			

									}// end general widget area 

									?>
            </div>
          </div>
          <div id="footcol3"  class="three columns">
            <div class="widget-area">
              <?php 

									if ( ! dynamic_sidebar( 'footer3' ) ){



									}// end general widget area 

									?>
            </div>
          </div>
          <div id="footcol4"  class="three columns">
            <div class="widget-area">
              <?php 

									if ( ! dynamic_sidebar( 'footer4' ) ){

						

									}// end general widget area 

									?>
            </div>
          </div>
          <div class="clear"></div>
        </footer>
      </div>
    </div>
  </div>
</div>

<!-- END FOOTER SIDEBAR -->

<?php } ?>

<!-- FOOTER -->

<div id="outerfooter">
  <div id="footercontainer">
    <div class="container">
      <div class="row">
        <div class="twelve columns">
          <footer id="footer">
          <div class="footer-menu"><?php
		  $menuParameters = array(
			  'container'       => false,
			  'echo'            => false,
			  'items_wrap'      => '%3$s',
			  'depth'           => 0,
			  'theme_location'  => 'footer-menu',
			  'container_class' => 'footer-menu'
			);
			echo strip_tags(wp_nav_menu( $menuParameters ), '<a>' );
			?>
			</div>
            <div class="logo-bot"><a href="/">
            <?php echo bloginfo( 'name' ) ?></a>
            <div class="copyrighttext">
              <?php echo date("Y"); ?> &copy; <?php print bloginfo('name'); ?>
            </div>
            </div>
            <div class="theme-credits">
              <a href="http://pornaffiliate.xxx/wordpress-porn-themes/#3" rel="external nofollow" target="_blank"><span class="porn">Porn</span> <span class="theme">Theme 3</span></a>
            </div>
            <div class="rta-label">
            <img src="<?php echo bloginfo('template_url') ?>/includes/rta88x31.gif" alt="RTA - Restricted To Adults" />
            </div>
          </footer>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- END FOOTER -->

</div>
<!-- end outercontainer -->

</div>
<!-- end bodychild -->

<?php get_template_part('site-footer'); ?>
