<?php

/**

 * The default template for displaying content. Used for both single and index/archive/search.

 *

 * @package WordPress

 * @subpackage Klasik

 * @since Klasik 1.0

 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
  <?php if( get_post_meta($post->ID, 'video', true) ) : ?>
  <a href="<?php echo the_permalink(); ?>" class="video-thumb">
  <?php else : ?>
  <a href="<?php echo get_post_meta($post->ID, 'link', true); ?>" target="_blank" class="video-thumb">
  <?php endif; ?>
  <?php if(is_home()) { the_date('m/d/y', '<div class="thumb-date">', '</div>'); } ?>
  <div class="go2">Play</div>
  <?php if ( has_post_thumbnail() ) {the_post_thumbnail('porn-theme-3-thumb');} ?>
  <?php if( get_post_meta($post->ID, 'quality', true) ) : ?>
  <div class="thumb-quality"><?php echo get_post_meta($post->ID, 'quality', true); ?></div>
  <?php endif; ?>
  <?php if( get_post_meta($post->ID, 'duration', true) ) : ?>
  <div class="thumb-duration"><?php echo get_post_meta($post->ID, 'duration', true); ?></div>
  <?php endif; ?>
  </a>
  <div class="thumb-tags">
    <?php the_tags('Niches: ') ?>
  </div>
  <div class="thumb-cat">Girls:
    <?php the_category(', ') ?>
  </div>
</article>
<!-- end post --> 

