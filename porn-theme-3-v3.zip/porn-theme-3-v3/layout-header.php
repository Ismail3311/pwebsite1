<!-- MAIN CONTENT -->

<div id="outermain">
<div id="maincontainer">
<div id="maincontent-container">
<div class="container">
<div class="row">
<?php 

                    $sidebarposition = esc_attr(klasik_get_option( 'klasik_sidebar_position' ,'two-col-left')); 

                    

                    if(is_home()){

						$pid = get_option('page_for_posts');

					}else{

						$pid = '';

					}

                    $custom_fields = klasik_get_customdata($pid);

                    

                    $pagelayout = $sidebarposition;

					

                    if(klasik_get_metabox('klasik_layout') && klasik_get_metabox('klasik_layout')!='default' && is_search()!='default'){

                        $pagelayout = esc_attr(klasik_get_metabox('klasik_layout'));

                    }

                    

                    if($pagelayout!='one-col'){

                        $mcontentclass = "hassidebar";

						$contentclass = 'contentcol columns ';

						

                        if($pagelayout=="two-col-left"){

                            $mcontentclass .= " mborderright";

							$contentclass .= "positionleft";

                        }else{

                            $mcontentclass .= " mborderleft";

							$contentclass .= "positionright";

                        }

                    }else{

                        $mcontentclass = "twelve columns";

						$contentclass = '';

                    }

		

                    ?>
<section id="maincontent" class="<?php echo $mcontentclass; ?>">
<section id="content" class="<?php echo $contentclass; ?>">
<div id="above-content-widgets" class="content-widgets">
<?php if(is_active_sidebar('contentbottom') ){ ?><?php if ( ! dynamic_sidebar( 'contentbottom' ) ){ }?> <?php } ?>
</div>
<?php 

								$nocont="";

								if(!empty($post))

								if(get_the_content()== "" && is_page() && !is_page_template()){$nocont="nocontent";} 

							?>
<div class="main <?php echo $nocont; ?>">
